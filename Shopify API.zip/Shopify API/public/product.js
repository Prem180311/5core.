const path = require('path');
const express = require('express');
const cors = require('cors');
const request = require('request');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Shopify credentials
const apikey = 'be16bb250f1e902f3b72c6ce4d581250';
const password = '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';
const shop = '5-core.myshopify.com';
const endpoint = 'products';
const apiVersion = '2024-01';

// Health check route
app.get('/', (req, res) => res.send('Server is up'));

// Shopify data route
app.get('/getdata', (req, res) => {
  const url = `https://${apikey}:${password}@${shop}/admin/api/${apiVersion}/${endpoint}.json`;

app.get('/getdata', async (req, res) => {
  const products = await fetchShopifyDataSomehow(); // however you're getting data
  res.json({ products });
});
  const options = {
    method: 'GET',
    url: url,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  request(options, (error, response, body) => {
    if (error) {
      console.error('Error:', error);
      return res.status(500).json({ error: 'Failed to fetch data from Shopify' });
    }

    if (response.statusCode !== 200) {
      console.error('Status Code:', response.statusCode, 'Body:', body);
      return res.status(response.statusCode).json({ error: 'Shopify API error', body });
    }

    try {
      const data = JSON.parse(body);
      res.status(200).json(data);
    } catch (parseError) {
      console.error('Parse Error:', parseError);
      res.status(500).json({ error: 'Failed to parse Shopify response' });
    }
    
  });
});

// Start the server only once
app.listen(3400, () => {
  console.log('✅ Server running at http://localhost:3400');
});
window.onload = async function loadProducts() {
  try {
    const response = await fetch('http://localhost:3400/getdata');
    
    const json = await response.json();

    const tbody = document.getElementById('products-body');
    tbody.innerHTML = ''; // Clear old rows

    if (!json.products || json.products.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9">No products returned.</td></tr>';
      return;
    }

    json.products.forEach((p, index) => {
      const variantsHTML = (p.variants || []).map(v =>
        `<div class="variant">
          <span class="small"><strong>Title:</strong> ${v.title}</span><br>
          <span class="small"><strong>SKU:</strong> ${v.sku || '—'}</span>,
          <span class="small"><strong>Price:</strong> ${v.price}</span>,
          <span class="small"><strong>Inv:</strong> ${v.inventory_quantity}</span>
        </div>`
      ).join('');

      const imgHTML = p.image?.src
        ? `<img src="${p.image.src}" alt="Product Image">`
        : '—';

      const datesHTML = `
        <div class="small"><strong>Created:</strong> ${p.created_at}</div>
        <div class="small"><strong>Updated:</strong> ${p.updated_at}</div>
        <div class="small"><strong>Published:</strong> ${p.published_at}</div>
      `;

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${p.id}</td>
        <td>
          <strong>${p.title}</strong><br>
          <span class="small">/${p.handle}</span>
        </td>
        <td>
          <span class="small"><strong>Vendor:</strong> ${p.vendor}</span><br>
          <span class="small"><strong>Type:</strong> ${p.product_type}</span>
        </td>
        <td>${p.tags || '—'}</td>
        <td>${p.status}</td>
        <td>${datesHTML}</td>
        <td>${variantsHTML}</td>
        <td>${imgHTML}</td>
      `;
      tbody.appendChild(row);
    });

  } catch (error) {
    console.error("🔴 Error fetching data:", error);
    document.getElementById('products-body').innerHTML =
      '<tr><td colspan="9">Error loading data. Check console.</td></tr>';
  }
};
window.onload = async () => {
  try {
    const response = await fetch('http://localhost:3400/getdata');
    const data = await response.json();

    const tbody = document.getElementById('products-body');
    tbody.innerHTML = '';

    if (!data.products || data.products.length === 0) {
      tbody.innerHTML = '<tr><td colspan="2">No products found.</td></tr>';
      return;
    }

    data.products.forEach((product, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${product.title}</td>
      `;
      tbody.appendChild(row);
    });
  } catch (err) {
    console.error('🔴 Fetch error:', err);
    document.getElementById('products-body').innerHTML =
      '<tr><td colspan="2">Error loading data. Check console.</td></tr>';
  }
};


